#ifndef BTREEOUT_H
#define BTREEOUT_H

#include <string>
#include <vector>
#include <memory>
using namespace std;

class BinaryTree {
public:
    int value;
    BinaryTree* left;
    BinaryTree* right;

    BinaryTree(int val, BinaryTree* l = nullptr, BinaryTree* r = nullptr) : value(val), left(l), right(r) {}

    void dump4(bool high = true) const;
    std::string toString() const;

private:
    static void dump4_impl(const BinaryTree* node, bool high, const std::vector<std::string>& lpref = std::vector<std::string>(), const std::vector<std::string>& cpref = std::vector<std::string>(), const std::vector<std::string>& rpref = std::vector<std::string>(), bool root = true, bool left = true, std::shared_ptr<std::vector<std::vector<std::string>>> lines = nullptr);

    static std::string ch_hor, ch_ver, ch_ddia, ch_rddia, ch_udia, ch_ver_hor, ch_udia_hor, ch_ddia_hor, ch_ver_spa;
};

#endif // BTREEOUT_H 