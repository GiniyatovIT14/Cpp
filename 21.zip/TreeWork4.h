#include "BTreeOut.h"
#include <vector>
#include <istream>
#include <set>

class TreeWork4 {
public:
    TreeWork4();
    ~TreeWork4();
    void Input();
    void PrintTree();
    void PrintLeaves();
    void SetRoot(BinaryTree* Root);
    void InputFromFile(std::istream& In);
    void InputConsoleElements(int Count);
    void InputRandomElements(int Count, int MinVal, int MaxVal);
    void InputConsole();
    void InputRandom();
    void InputFile();
private:
    BinaryTree* Root;
    BinaryTree* InputTreeFromFile(std::istream& In);
    void PrintLeavesHelper(BinaryTree* Node);
    void ClearTree(BinaryTree* Node);
    void InsertNode(BinaryTree*& Node, int Value);
};