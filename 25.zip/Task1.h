#pragma once
#include <iostream>

class RightTriangle {
private:
    double a, b;
    bool lastError;  // Flag to indicate if last operation had an error
    const char* errorMessage;  // Message describing the last error

public:
    RightTriangle();
    RightTriangle(double a, double b);
    RightTriangle(double side);
    RightTriangle(const RightTriangle& other);

    bool setA(double value);
    bool setB(double value);

    double getA() const;
    double getB() const;

    double area() const;
    bool hasError() const { return lastError; }
    const char* getErrorMessage() const { return errorMessage; }
    void clearError() { lastError = false; errorMessage = nullptr; }

    RightTriangle& operator++();
    RightTriangle& operator--();

    explicit operator double() const;
    operator bool() const;

    bool operator<=(const RightTriangle& other) const;
    bool operator>=(const RightTriangle& other) const;

    friend std::ostream& operator<<(std::ostream& os, const RightTriangle& triangle);
};