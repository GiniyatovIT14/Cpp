#ifndef BTREEOUT_H
#define BTREEOUT_H

#include <string>
#include <vector>
#include <memory>
using namespace std;

class BinaryTree {
public:
    int value;
    BinaryTree* left;
    BinaryTree* right;

    BinaryTree(int val, BinaryTree* l = nullptr, BinaryTree* r = nullptr) : value(val), left(l), right(r) {}

    void dump4(bool high = true) const;
    string toString() const;

private:
    static void dump4_impl(const BinaryTree* node, bool high, const vector<string>& lpref = vector<string>(), const vector<string>& cpref = vector<string>(), const vector<string>& rpref = vector<string>(), bool root = true, bool left = true, shared_ptr<vector<vector<string>>> lines = nullptr);

    static string ch_hor, ch_ver, ch_ddia, ch_rddia, ch_udia, ch_ver_hor, ch_udia_hor, ch_ddia_hor, ch_ver_spa;
};

#endif // BTREEOUT_H 