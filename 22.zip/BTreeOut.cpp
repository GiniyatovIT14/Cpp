#include "BTreeOut.h"
#include <iostream>
#include <functional>
#include <algorithm>
#include <tuple>
#include <stdexcept>

using namespace std;

string BinaryTree::ch_hor = "-";
string BinaryTree::ch_ver = "|";
string BinaryTree::ch_ddia = "/";
string BinaryTree::ch_rddia = "\\";
string BinaryTree::ch_udia = "\\";
string BinaryTree::ch_ver_hor = "|-";
string BinaryTree::ch_udia_hor = "\\-";
string BinaryTree::ch_ddia_hor = "/-";
string BinaryTree::ch_ver_spa = "| ";

string BinaryTree::toString() const {
    switch (value) {
    case -1: return "+";
    case -2: return "-";
    case -3: return "*";
    case -4: return "/";
    case -5: return "%";
    case -6: return "^";
    default: return to_string(value);
    }
}

void BinaryTree::dump4(bool high) const {
    dump4_impl(this, high);
}

void BinaryTree::dump4_impl(const BinaryTree* node, bool high, const vector<string>& lpref, const vector<string>& cpref, const vector<string>& rpref, bool root, bool left, shared_ptr<vector<vector<string>>> lines) {
    if (!node) return;
    typedef vector<string> VS;
    auto VSCat = [](VS const& a, VS const& b) { auto r = a; r.insert(r.end(), b.begin(), b.end()); return r; };
    if (root) lines = make_shared<vector<VS>>();
    if (node->left)
        dump4_impl(node->left, high, VSCat(lpref, high ? VS({ " ", " " }) : VS({ " " })), VSCat(lpref, high ? VS({ ch_ddia, ch_ver }) : VS({ ch_ddia })), VSCat(lpref, high ? VS({ ch_hor, " " }) : VS({ ch_hor })), false, true, lines);
    auto sval = std::to_string(node->value);
    size_t sm = left || sval.empty() ? sval.size() / 2 : ((sval.size() + 1) / 2 - 1);
    for (size_t i = 0; i < sval.size(); ++i)
        lines->push_back(VSCat(i < sm ? lpref : i == sm ? cpref : rpref, { string(1, sval[i]) }));
    if (node->right)
        dump4_impl(node->right, high, VSCat(rpref, high ? VS({ ch_hor, " " }) : VS({ ch_hor })), VSCat(rpref, high ? VS({ ch_rddia, ch_ver }) : VS({ ch_rddia })), VSCat(rpref, high ? VS({ " ", " " }) : VS({ " " })), false, false, lines);
    if (root) {
        VS out;
        for (size_t l = 0;; ++l) {
            bool last = true;
            string line;
            for (size_t i = 0; i < lines->size(); ++i)
                if (l < (*lines).at(i).size()) {
                    line += lines->at(i)[l];
                    last = false;
                }
                else line += " ";
            if (last) break;
            out.push_back(line);
        }
        for (size_t i = 0; i < out.size(); ++i)
            cout << out[i] << endl;
    }
}